class Ticket {
  String name;
  String destination;
  DateTime date;

  Ticket({
    required this.name,
    required this.destination,
    required this.date,
  });
}
