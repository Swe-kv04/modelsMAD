import 'package:flutter/material.dart';
import '../models/ticket.dart';

class AddEditTicketScreen extends StatefulWidget {
  final Ticket? ticket;

  const AddEditTicketScreen({super.key, this.ticket});

  @override
  State<AddEditTicketScreen> createState() => _AddEditTicketScreenState();
}

class _AddEditTicketScreenState extends State<AddEditTicketScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameController;
  late TextEditingController _destinationController;
  DateTime? _selectedDate;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.ticket?.name ?? '');
    _destinationController =
        TextEditingController(text: widget.ticket?.destination ?? '');
    _selectedDate = widget.ticket?.date ?? DateTime.now();
  }

  void _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  void _saveTicket() {
    if (_formKey.currentState!.validate()) {
      final ticket = Ticket(
        name: _nameController.text,
        destination: _destinationController.text,
        date: _selectedDate!,
      );
      Navigator.pop(context, ticket);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text(widget.ticket == null ? "Add Ticket" : "Edit Ticket")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(labelText: "Passenger Name"),
                validator: (val) =>
                    val == null || val.isEmpty ? "Enter name" : null,
              ),
              TextFormField(
                controller: _destinationController,
                decoration: const InputDecoration(labelText: "Destination"),
                validator: (val) =>
                    val == null || val.isEmpty ? "Enter destination" : null,
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Text("Date: ${_selectedDate?.toLocal()}".split(' ')[0]),
                  const SizedBox(width: 16),
                  ElevatedButton(
                    onPressed: _pickDate,
                    child: const Text("Pick Date"),
                  ),
                ],
              ),
              const Spacer(),
              ElevatedButton(
                onPressed: _saveTicket,
                child: const Text("Save"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
