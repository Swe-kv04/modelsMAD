package com.example.ticket

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
