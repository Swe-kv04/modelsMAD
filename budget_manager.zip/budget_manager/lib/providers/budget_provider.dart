import 'package:flutter/material.dart';
import '../models/budget.dart';

class BudgetProvider with ChangeNotifier {
  Budget _budget = Budget(income: 0, expenses: 0, savingsGoal: 0);

  Budget get budget => _budget;

  void updateIncome(double income) {
    _budget.income = income;
    notifyListeners();
  }

  void updateExpenses(double expenses) {
    _budget.expenses = expenses;
    notifyListeners();
  }

  void updateSavingsGoal(double goal) {
    _budget.savingsGoal = goal;
    notifyListeners();
  }
}
