class Budget {
  double income;
  double expenses;
  double savingsGoal;

  Budget({
    required this.income,
    required this.expenses,
    required this.savingsGoal,
  });

  double get balance => income - expenses;
  double get savedAmount => income - expenses;
  double get progress => savingsGoal == 0 ? 0 : savedAmount / savingsGoal;
}
