import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/budget_provider.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _incomeController = TextEditingController();
  final _expensesController = TextEditingController();
  final _goalController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final budgetProvider = context.watch<BudgetProvider>();
    final budget = budgetProvider.budget;

    return Scaffold(
      appBar: AppBar(title: const Text("Budget Manager")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            _buildInputField("Monthly Income", _incomeController, (val) {
              budgetProvider.updateIncome(double.tryParse(val) ?? 0);
            }),
            _buildInputField("Monthly Expenses", _expensesController, (val) {
              budgetProvider.updateExpenses(double.tryParse(val) ?? 0);
            }),
            _buildInputField("Saving Goal", _goalController, (val) {
              budgetProvider.updateSavingsGoal(double.tryParse(val) ?? 0);
            }),
            const SizedBox(height: 20),
            Text("Remaining Balance: ₹${budget.balance.toStringAsFixed(2)}"),
            const SizedBox(height: 10),
            Text(
                "Savings Progress: ${(budget.progress * 100).clamp(0, 100).toStringAsFixed(1)}%"),
            const SizedBox(height: 10),
            LinearProgressIndicator(
              value: budget.progress.clamp(0, 1),
              backgroundColor: Colors.grey[300],
              color: Colors.green,
              minHeight: 10,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInputField(String label, TextEditingController controller,
      Function(String) onChanged) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
        keyboardType: TextInputType.number,
        onChanged: onChanged,
      ),
    );
  }
}
