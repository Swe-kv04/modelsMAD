package com.example.note_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
