import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/note_provider.dart';
import 'note_editor_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final notes = context.watch<NoteProvider>().notes;

    return Scaffold(
      appBar: AppBar(title: const Text("My Notes")),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const NoteEditorScreen()),
        ),
        child: const Icon(Icons.add),
      ),
      body: ListView.builder(
        itemCount: notes.length,
        itemBuilder: (ctx, i) {
          return ListTile(
            title: Text(notes[i].title),
            subtitle: Text(notes[i].content),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => NoteEditorScreen(note: notes[i], index: i),
              ),
            ),
          );
        },
      ),
    );
  }
}
