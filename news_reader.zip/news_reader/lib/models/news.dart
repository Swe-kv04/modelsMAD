class News {
  final String title;
  final String description;

  News({required this.title, required this.description});
}
