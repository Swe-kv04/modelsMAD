import 'package:flutter/material.dart';
import '../models/news.dart';
import 'news_detail_screen.dart';

class HomeScreen extends StatelessWidget {
  final List<News> newsList = [
    News(
      title: "Flutter 3.0 Released!",
      description:
          "Flutter 3.0 brings performance improvements and more widgets for cross-platform development.",
    ),
    News(
      title: "AI Revolution 2025",
      description:
          "Experts believe 2025 will be a major turning point for AI adoption worldwide.",
    ),
    News(
      title: "SpaceX Launch Successful",
      description:
          "SpaceX successfully launched another batch of Starlink satellites into orbit.",
    ),
  ];

  HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("News Headlines")),
      body: ListView.builder(
        itemCount: newsList.length,
        itemBuilder: (context, index) {
          final news = newsList[index];
          return Card(
            margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
            child: ListTile(
              title: Text(news.title),
              trailing: const Icon(Icons.arrow_forward_ios, size: 16),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => NewsDetailScreen(news: news),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
