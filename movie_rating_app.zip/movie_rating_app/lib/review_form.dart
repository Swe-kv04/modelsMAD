import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class ReviewForm extends StatefulWidget {
  final String movieId;

  const ReviewForm({super.key, required this.movieId});

  @override
  State<ReviewForm> createState() => _ReviewFormState();
}

class _ReviewFormState extends State<ReviewForm> {
  final _formKey = GlobalKey<FormState>();
  double _rating = 3;
  String _reviewText = '';
  bool _isSubmitting = false;

  Future<void> _submitReview() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isSubmitting = true);
    _formKey.currentState!.save();

    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    await FirebaseFirestore.instance
        .collection('movies')
        .doc(widget.movieId)
        .collection('reviews')
        .add({
      'userId': user.uid,
      'userEmail': user.email,
      'rating': _rating,
      'review': _reviewText,
      'timestamp': FieldValue.serverTimestamp(),
    });

    setState(() {
      _isSubmitting = false;
      _rating = 3;
      _reviewText = '';
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Review submitted')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          DropdownButtonFormField<double>(
            value: _rating,
            decoration: const InputDecoration(labelText: 'Rating'),
            items: [1, 2, 3, 4, 5]
                .map((e) => DropdownMenuItem(value: e.toDouble(), child: Text('$e')))
                .toList(),
            onChanged: (value) => setState(() => _rating = value ?? 3),
          ),
          TextFormField(
            decoration: const InputDecoration(labelText: 'Write a review'),
            maxLines: 3,
            onSaved: (value) => _reviewText = value ?? '',
            validator: (value) => value == null || value.isEmpty ? 'Review cannot be empty' : null,
          ),
          const SizedBox(height: 10),
          _isSubmitting
              ? const CircularProgressIndicator()
              : ElevatedButton(
                  onPressed: _submitReview,
                  child: const Text('Submit Review'),
                ),
        ],
      ),
    );
  }
}
