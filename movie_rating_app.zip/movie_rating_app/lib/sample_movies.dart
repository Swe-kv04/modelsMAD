import 'model/movie.dart';

final List<Movie> allMovies = [
  Movie(
    id: "1",
    title: 'harry potter',
    genre: 'Sci-Fi',
    releaseDate: '2010',
    description: 'A mind-bending thriller by Christopher Nolan.',
  ),
  Movie(
    id: "2",
    title: 'The Dark Knight',
    genre: 'Action',
    releaseDate: '2008',
    description: 'Batman faces the Joker in Gotham.',
  ),
  Movie(
    id: "3",
    title: 'Interstellar',
    genre: 'Sci-Fi',
    releaseDate: '2014',
    description: 'A space journey beyond time and dimension.',
  ),
];
