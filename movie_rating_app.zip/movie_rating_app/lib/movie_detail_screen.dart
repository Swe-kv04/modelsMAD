import 'package:flutter/material.dart';
import 'model/movie.dart';
import 'review_form.dart'; // <- We'll create this next
import 'review_list.dart';


class MovieDetailScreen extends StatelessWidget {
  final Movie movie;

  const MovieDetailScreen({super.key, required this.movie});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(movie.title),
      backgroundColor: Colors.blueAccent,),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Genre: ${movie.genre}', style: const TextStyle(fontSize: 16)),
            Text('Release Date: ${movie.releaseDate}', style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 20),
            const Text("Leave a Review", style: TextStyle(fontSize: 20)),
            const SizedBox(height: 10),
            ReviewForm(movieId: movie.id), // <- Add this
            const SizedBox(height: 20),
            const Text("Recent Reviews", style: TextStyle(fontSize: 18)),
            const SizedBox(height: 10),
            ReviewList(movieId: movie.id),

          ],
        ),
      ),
    );
  }
}
