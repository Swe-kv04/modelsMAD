import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class ReviewList extends StatelessWidget {
  final String movieId;

  const ReviewList({super.key, required this.movieId});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance
          .collection('movies')
          .doc(movieId)
          .collection('reviews')
          .orderBy('timestamp', descending: true)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return const Text("Error loading reviews.");
        }
        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return const Text("No reviews yet. Be the first!");
        }

        final reviews = snapshot.data!.docs;

        return ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: reviews.length,
          itemBuilder: (context, index) {
            final review = reviews[index];
            return Card(
              color: const Color.fromARGB(255, 157, 214, 240),
              margin: const EdgeInsets.symmetric(vertical: 6),
              child: ListTile(
                title: Text('${review['rating']} ⭐ - ${review['userEmail']}'),
                subtitle: Text(review['review']),
              ),
            );
          },
        );
      },
    );
  }
}
