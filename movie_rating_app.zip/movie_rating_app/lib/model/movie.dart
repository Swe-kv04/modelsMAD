class Movie {
  final String id;
  final String title;
  final String genre;
  final String releaseDate;
  final String description;

  Movie({
    required this.id,
    required this.title,
    required this.genre,
    required this.releaseDate,
    required this.description,
  });

  factory Movie.fromFirestore(String id, Map<String, dynamic> data) {
    return Movie(
      id: id,
      title: data['title'] ?? '',
      genre: data['genre'] ?? '',
      releaseDate: data['releaseDate'] ?? '',
      description: data['description'] ?? '',
    );
  }
}
