class Review {
  final String id;
  final String userId;
  final int rating;
  final String comment;

  Review({
    required this.id,
    required this.userId,
    required this.rating,
    required this.comment,
  });

  factory Review.fromMap(String id, Map<String, dynamic> data) {
    return Review(
      id: id,
      userId: data['userId'] ?? '',
      rating: data['rating'] ?? 0,
      comment: data['comment'] ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'rating': rating,
      'comment': comment,
      'timestamp': DateTime.now(),
    };
  }
}
