import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:movie_rating_app/movie_detail_screen.dart';
import 'model/movie.dart';

class MovieCatalog extends StatefulWidget {
  const MovieCatalog({super.key});

  @override
  State<MovieCatalog> createState() => _MovieCatalogState();
}

class _MovieCatalogState extends State<MovieCatalog> {
  String searchQuery = '';
  String selectedGenre = 'All';

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('movies').snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        List<Movie> movies = snapshot.data!.docs.map((doc) {
          return Movie.fromFirestore(doc.id, doc.data() as Map<String, dynamic>);
        }).toList();

        List<Movie> filtered = movies.where((movie) {
          final matchesSearch = movie.title.toLowerCase().contains(searchQuery.toLowerCase());
          final matchesGenre = selectedGenre == 'All' || movie.genre == selectedGenre;
          return matchesSearch && matchesGenre;
        }).toList();

        return Column(
          children: [
            TextField(
              decoration: const InputDecoration(labelText: 'Search movies'),
              onChanged: (value) => setState(() => searchQuery = value),
            ),
            const SizedBox(height: 10),
            DropdownButton<String>(
              value: selectedGenre,
              onChanged: (value) => setState(() => selectedGenre = value!),
              items: ['All', 'sci-fi', 'action', 'romance'].map((genre) {
                return DropdownMenuItem(value: genre, child: Text(genre));
              }).toList(),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                itemCount: filtered.length,
                itemBuilder: (context, index) {
                  final movie = filtered[index];
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 12.0),
                    child: Container(
                      decoration: BoxDecoration(
                        color: const Color.fromARGB(255, 133, 209, 244),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: ListTile(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => MovieDetailScreen(movie: movie),
                            ),
                          );
                        },
                        title: Text(movie.title),
                        subtitle: Text('${movie.genre} • ${movie.releaseDate}'),
                      ),
                    ),
                  );
                },
              ),
            ),

          ],
        );
      },
    );
  }
}
