package com.example.movie_rating_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
